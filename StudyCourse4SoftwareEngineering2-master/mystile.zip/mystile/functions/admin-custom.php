<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
// The contents of this file has ben deprecated, in favour of the WF_Meta and WF_Fields_Meta classes.
?>